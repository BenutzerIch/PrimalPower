import React, { useState } from 'react';
import { ChevronRight, Dumbbell, Leaf, Brain, Shield, Timer, Target, CheckCircle2 } from 'lucide-react';

function App() {
  const [selectedDuration, setSelectedDuration] = useState('1');
  const [includeWorkout, setIncludeWorkout] = useState(false);

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1490645935967-10de6ba17061" 
            alt="Fresh organic ingredients"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/40"></div>
        </div>
        
        <nav className="relative z-10 flex justify-between items-center px-8 py-6">
          <h1 className="text-3xl font-bold text-white flex items-center gap-2">
            <Leaf className="h-8 w-8" />
            Primal Power
          </h1>
          <div className="flex gap-8 text-white">
            <a href="#programs" className="hover:text-green-400 transition">Programs</a>
            <a href="#philosophy" className="hover:text-green-400 transition">Philosophy</a>
            <a href="#pricing" className="hover:text-green-400 transition">Pricing</a>
            <button className="bg-green-600 px-6 py-2 rounded-full hover:bg-green-700 transition">
              Join Now
            </button>
          </div>
        </nav>

        <div className="relative z-10 flex flex-col items-center justify-center h-[calc(100vh-5rem)] text-center px-4">
          <h2 className="text-5xl md:text-7xl font-bold text-white mb-6">
            Elite Natural Fitness
          </h2>
          <p className="text-xl text-white/90 max-w-2xl mb-8">
            Join the exclusive community of high-performers who trust only natural nutrition 
            and science-backed training methods for exceptional results.
          </p>
          <a href="#pricing" className="bg-green-600 text-white px-8 py-3 rounded-full text-lg font-semibold flex items-center gap-2 hover:bg-green-700 transition">
            Transform Your Life <ChevronRight className="h-5 w-5" />
          </a>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-20 px-8">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          <FeatureCard 
            icon={<Target />}
            title="Tailored Plans for Every Goal"
            description="Customized nutrition and training programs designed specifically for your body and objectives."
          />
          <FeatureCard 
            icon={<Leaf />}
            title="100% Natural Nutrition"
            description="Pure, whole foods only. No artificial supplements, sweeteners, or processed ingredients."
          />
          <FeatureCard 
            icon={<Shield />}
            title="Backed by Science"
            description="Evidence-based protocols trusted by professional athletes and health experts."
          />
        </div>
      </section>

      {/* Programs Preview */}
      <section className="bg-stone-100 py-20 px-8">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16">Elite Training Programs</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ProgramCard 
              image="https://images.unsplash.com/photo-1526506118085-60ce8714f8c5"
              title="HIIT Performance"
              description="High-intensity interval training focused on building strength and burning fat efficiently."
              features={[
                "Scientifically optimized workout intervals",
                "Natural pre/post nutrition protocols",
                "Progressive overload tracking"
              ]}
            />
            <ProgramCard 
              image="https://images.unsplash.com/photo-1517838277536-f5f99be501cd"
              title="Volume Excellence"
              description="Comprehensive volume training program for building endurance and lean muscle mass."
              features={[
                "Structured progressive routines",
                "Recovery optimization protocols",
                "Natural performance nutrition"
              ]}
            />
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Investment in Excellence</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Choose your commitment to transformation. All plans include personalized guidance
            and premium support throughout your journey.
          </p>
          
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <div className="flex flex-col gap-8">
              <div className="flex flex-col gap-4">
                <h3 className="text-xl font-semibold">Select Your Program Duration</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <PlanDurationButton
                    duration="1"
                    label="1 Month"
                    selected={selectedDuration === '1'}
                    onClick={() => setSelectedDuration('1')}
                  />
                  <PlanDurationButton
                    duration="3"
                    label="3 Months"
                    selected={selectedDuration === '3'}
                    onClick={() => setSelectedDuration('3')}
                  />
                  <PlanDurationButton
                    duration="6"
                    label="6 Months"
                    selected={selectedDuration === '6'}
                    onClick={() => setSelectedDuration('6')}
                  />
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <h3 className="text-xl font-semibold">Choose Your Program Type</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <ProgramTypeButton
                    type="nutrition"
                    selected={!includeWorkout}
                    onClick={() => setIncludeWorkout(false)}
                    price={getPriceForPlan(selectedDuration, false)}
                  />
                  <ProgramTypeButton
                    type="complete"
                    selected={includeWorkout}
                    onClick={() => setIncludeWorkout(true)}
                    price={getPriceForPlan(selectedDuration, true)}
                  />
                </div>
              </div>

              <div className="border-t pt-8">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h3 className="text-2xl font-bold">Total Investment</h3>
                    <p className="text-gray-600">Billed once for the entire period</p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold">€{getPriceForPlan(selectedDuration, includeWorkout)}</p>
                    <p className="text-green-600">Save up to 40% with longer plans</p>
                  </div>
                </div>
                <button className="w-full bg-green-600 text-white py-4 rounded-xl font-semibold text-lg hover:bg-green-700 transition flex items-center justify-center gap-2">
                  Start Your Transformation <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-20 px-8 bg-green-600 text-white">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
          <StatCard icon={<Target />} text="Tailored Plans for Every Fitness Goal" />
          <StatCard icon={<Leaf />} text="100% Natural Nutrition – No Artificial Additives" />
          <StatCard icon={<Shield />} text="Backed by Science, Trusted by Athletes" />
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="flex flex-col items-center text-center p-6 rounded-xl bg-white shadow-lg hover:shadow-xl transition">
      <div className="w-16 h-16 flex items-center justify-center rounded-full bg-green-100 text-green-600 mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
}

function ProgramCard({ image, title, description, features }) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition">
      <img src={image} alt={title} className="w-full h-64 object-cover" />
      <div className="p-6">
        <h3 className="text-2xl font-semibold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        <ul className="space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center gap-2 text-gray-700">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              {feature}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function StatCard({ icon, text }) {
  return (
    <div className="flex flex-col items-center">
      <div className="mb-4 bg-white/10 p-4 rounded-full">{icon}</div>
      <div className="text-lg font-medium">{text}</div>
    </div>
  );
}

function PlanDurationButton({ duration, label, selected, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`p-4 rounded-xl border-2 transition ${
        selected 
          ? 'border-green-600 bg-green-50 text-green-600' 
          : 'border-gray-200 hover:border-green-600 hover:bg-green-50'
      }`}
    >
      <div className="font-semibold">{label}</div>
      <div className="text-sm text-gray-600">
        {duration === '3' ? 'Save 25%' : duration === '6' ? 'Save 40%' : 'Full Price'}
      </div>
    </button>
  );
}

function ProgramTypeButton({ type, selected, onClick, price }) {
  return (
    <button
      onClick={onClick}
      className={`p-6 rounded-xl border-2 transition text-left ${
        selected 
          ? 'border-green-600 bg-green-50' 
          : 'border-gray-200 hover:border-green-600 hover:bg-green-50'
      }`}
    >
      <div className="flex justify-between items-start mb-2">
        <h4 className="text-lg font-semibold">
          {type === 'nutrition' ? 'Nutrition Only' : 'Complete Program'}
        </h4>
        <div className="text-green-600 font-semibold">€{price}</div>
      </div>
      <p className="text-gray-600 text-sm">
        {type === 'nutrition' 
          ? 'Personalized nutrition plans and guidance'
          : 'Nutrition plans plus workout programs'}
      </p>
    </button>
  );
}

function getPriceForPlan(duration, includeWorkout) {
  const prices = {
    '1': { nutrition: 29.99, complete: 44.99 },
    '3': { nutrition: 74.99, complete: 89.99 },
    '6': { nutrition: 129.99, complete: 144.99 }
  };
  
  return prices[duration][includeWorkout ? 'complete' : 'nutrition'];
}

export default App;